from rules import get_response

def run_chatbot():
    print("Chatbot: Hi! I am a simple rule-based chatbot.")
    print("Chatbot: Type 'bye' to exit.\n")

    while True:
        user_input = input("You: ")

        # Exit condition
        if user_input.lower().strip() == "bye":
            print("Chatbot: Goodbye! Have a great day!")
            break

        # Get response from rules
        bot_reply = get_response(user_input)
        print("Chatbot:", bot_reply)


if __name__ == "__main__":
    run_chatbot()
