def get_response(user_input: str) -> str:
    message = user_input.lower().strip()
  
    if message in ["hi", "hello", "hey", "hola"]:
        return "Hello! How can I help you today?"

    elif "your name" in message:
        return "I am a simple Python chatbot created using rule-based logic."
      
    elif "how are you" in message:
        return "I'm just a program, but I'm doing great! Thanks for asking."

    elif "weather" in message:
        return "I can't check live weather now, but I hope it's nice where you are!"

    elif "time" in message:
        return "I don't have a clock yet, but you can check the time on your device."

    elif "who are you" in message:
        return "I'm a rule-based chatbot here to practice conversation flow."

    elif "what can you do" in message:
        return "I can respond to some basic questions and show how rule-based chatbots work."

    # Exit condition handled in main.py, but we can still answer
    elif message in ["bye", "goodbye", "see you"]:
        return "Goodbye! It was nice talking to you."

    # Default response
    else:
        return "Sorry, I don't understand that yet. Can you rephrase or ask something simple?"
