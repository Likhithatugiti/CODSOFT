# rule-based-chatbot

# Simple Rule-Based Chatbot

This is a basic Python chatbot that responds to user input using predefined rules
implemented with `if-elif-else` statements.

## How it works

- The user types a message in the terminal.
- The program normalizes the input (lowercase, strip spaces).
- It checks for specific keywords like greetings, "how are you", "weather", etc.
- For each matched rule, it prints a predefined response.
- If no rule matches, it returns a default "I don't understand" message.

## How to run

```bash
# from the project root
cd chatbot
python main.py
